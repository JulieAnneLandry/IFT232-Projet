package chess;

public class P {

	public static void p(Object s) {
		System.out.println(s.toString());
	}

}
