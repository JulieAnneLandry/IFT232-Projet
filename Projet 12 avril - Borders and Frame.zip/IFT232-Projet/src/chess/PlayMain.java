package chess;

import javax.swing.JFrame;

import frames.ChessFrame;
import frames.ChessMenu;

public class PlayMain {

	public static void main(String[] args) {

		ChessFrame frame = new ChessFrame();
		
		
		
		/*ChessMenu menu;

		menu = new ChessMenu();

		Board grille = new Board();
		
		grille.afficherTout();
		Save s = new SavetoFile();
		s.save(grille);

		JFrame frame = new JFrame();
		frame.setTitle("�checs");
		frame.setJMenuBar(menu);
		frame.setSize(800, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.add(grille);
		frame.setVisible(true);*/

	}

}
