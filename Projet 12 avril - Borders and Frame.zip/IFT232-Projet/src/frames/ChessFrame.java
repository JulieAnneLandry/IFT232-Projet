package frames;

import java.awt.*;

import javax.swing.*;

import chess.Board;

public class ChessFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private Board board;
	private ChessMenu menu;

	public ChessFrame() {

		board = new Board();
		menu = new ChessMenu();

		initComponents();

		setJMenuBar(menu);

		setTitle("�checs");
		setSize(800, 700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);

	}

	public void initComponents() {

		Container pane = getContentPane();

		pane.setLayout(new GridLayout(1, 1));

		JPanel boardPanel = new JPanel();
		boardPanel.setLayout(new GridLayout(8, 8));

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				boardPanel.add(Board.getCase(i, j));
			}
		}

		pane.add(boardPanel);
	}

}
