package chess;

import java.util.ArrayList;

import pieces.Piece;

public abstract class Load
{
public abstract ArrayList<Piece> load();
}
