package chess;

public abstract class Save
{
 public abstract void save(Board b);
}
